from app.models import *
from django.contrib import admin


class ZamenaInline(admin.StackedInline):
    model = Zamena
    extra = 0


class RabotilnicaAdmin(admin.ModelAdmin):
    inlines = [ZamenaInline]

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class PopravaAdmin(admin.ModelAdmin):
    def save_model(self, request, obj, form, change):
        obj.user = request.user
        super().save_model( request, obj, form, change)


class AutomobileAdmin(admin.ModelAdmin):


    list_display = ["tip", "max_speed"]


class ProizvoditelAdmin(admin.ModelAdmin):
    list_display = ["ime"]

    def has_add_permission(self, request):
        return request.user.is_superuser

admin.site.register(Auto,AutomobileAdmin)
admin.site.register(Prozivoditel, ProizvoditelAdmin)

admin.site.register(Rabotilnica, RabotilnicaAdmin)

admin.site.register(Popravka,PopravaAdmin)

# Register your models here.
