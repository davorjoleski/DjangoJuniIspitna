from django import forms
from .models import Popravka


class PopravkaForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(PopravkaForm, self).__init__(*args, **kwargs)
        for field in self.visible_fields():
            field.field.widget.attrs['class'] = 'form-control'

    class Meta:
        model = Popravka
        exclude = ("user",)
       # fields = '__all__'
