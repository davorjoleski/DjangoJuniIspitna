from django.contrib.auth.models import User
from django.db import models


class Prozivoditel(models.Model):
    ime = models.CharField(max_length=255, null=False, blank=False)
    link = models.URLField()
    zemja = models.CharField(max_length=255, null=False, blank=False)
    sopstvenik = models.CharField(max_length=255, null=False, blank=False)

    def __str__(self):
        return self.ime


class Rabotilnica(models.Model):
    ime = models.CharField(max_length=255, null=False, blank=False)
    god = models.IntegerField()
    popravka_old_timer = models.BooleanField(default=True)

    def __str__(self):
        return self.ime


class Auto(models.Model):
    tip = models.CharField(max_length=255, null=False, blank=False)
    proizvoditel = models.ForeignKey(Prozivoditel, on_delete=models.CASCADE, null=False, blank=False)
    max_speed = models.IntegerField()
    boja = models.CharField(max_length=255, null=False, blank=False)

    def __str__(self):
        return self.tip


class Popravka(models.Model):
    code = models.CharField(max_length=255, null=False, blank=False)
    date = models.DateField()
    opis_problem = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=False)
    image = models.ImageField(upload_to="popravki")
    car = models.ForeignKey(Auto, on_delete=models.CASCADE, null=False)
    rabotilinca = models.ForeignKey(Rabotilnica, on_delete=models.CASCADE, null=False)

    def __str__(self):
        return self.code


class Zamena(models.Model):
    rabotilinca = models.ForeignKey(Rabotilnica, on_delete=models.CASCADE, null=False)
    proizvoditel = models.ForeignKey(Prozivoditel, on_delete=models.CASCADE, null=False)


# Create your models here.
