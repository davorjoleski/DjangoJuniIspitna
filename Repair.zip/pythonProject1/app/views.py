from app.models import Popravka
from django.shortcuts import render, redirect
from .form import PopravkaForm


def index(request):
    return render(request, "index.html")


def repairs(request):

    if request.method =="POST":
        form_data= PopravkaForm(data=request.POST,files=request.FILES)
        if form_data.is_valid():
            repair = form_data.save(commit=False)
            repair.user = request.user
            repair.image = form_data.cleaned_data['image']
            repair.save()
            return redirect("/repairs")

    query = Popravka.objects.filter(user=request.user,car__tip='sedan').all()
    context = {"rep": query, "form": PopravkaForm}
    return render(request, "repairs.html", context)

# Create your views here.
