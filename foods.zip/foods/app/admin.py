from app.models import *
from django.contrib import admin


class InlineProduct(admin.StackedInline):
    model = Product
    extra = 0  # dodavjne pamti


class ProductAdmin(admin.ModelAdmin):
    exclude = ["user", ]

    def save_model(self, request, obj, form, change):
        # Поставување на корисникот на продуктот на моментално најавениот корисник
        obj.user = request.user
        super().save_model(request, obj, form, change)

    def has_change_permission(self, request, obj=None):
        if obj and (obj.user == request.user):
            return True
        return False


class CategoryAdmin(admin.ModelAdmin):
    inlines = [InlineProduct]
    list_display = ["ime"]

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser


class ClinetAdmin(admin.ModelAdmin):
    list_display = ["ime", "prezime"]


class SaleItemAdmin(admin.StackedInline):
    model = SaleItem
    extra = 1


class SaleAdmin(admin.ModelAdmin):
    inlines = [SaleItemAdmin]


admin.site.register(Category, CategoryAdmin)
admin.site.register(Product, ProductAdmin)
admin.site.register(Client, ClinetAdmin)

admin.site.register(Sale, SaleAdmin)

# Register your models here.
