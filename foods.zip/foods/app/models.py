from django.contrib.auth.models import User
from django.db import models


class Client(models.Model):
    ime = models.CharField(max_length=255, null=False, blank=False)
    prezime = models.CharField(max_length=255, null=False, blank=False)
    email = models.EmailField(default="example@example.com")
    adresa = models.CharField(max_length=255, null=False, blank=False)

    def __str__(self):
        return f"{self.ime} {self.prezime}"


class Category(models.Model):
    ime = models.CharField(max_length=255, null=False, blank=False)
    description = models.TextField()
    active = models.BooleanField(default=False)

    def __str__(self):
        return self.ime


class Product(models.Model):
    code = models.AutoField(primary_key=True)
    ime = models.CharField(max_length=255, null=False, blank=False)
    description = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=False)
    image = models.ImageField(upload_to="foods")
    cena = models.FloatField(default=1)
    kolicina = models.IntegerField(default=1)
    kategorija = models.ForeignKey(Category, on_delete=models.CASCADE, null=False, blank=False)

    def __str__(self):
        return self.ime


class Sale(models.Model):
    date = models.DateField()
    client = models.ForeignKey(Client, on_delete=models.CASCADE, null=False)

    def __str__(self):
        return f'{self.date} - {self.client}'


class SaleItem(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, null=False)
    amount = models.IntegerField()
    sale = models.ForeignKey(Sale, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.sale} - {self.product}'
# Create your models here.
