from app.form import FoodForm
from django.shortcuts import render, redirect
from app.models import Product
from django import forms


def index(request):
    return render(request, "index.html")


def outofstock(request):
    if request.method == "POST":
        form_data = FoodForm(data=request.POST, files=request.FILES)
        if form_data.is_valid():
            repair = form_data.save(commit=False)
            repair.user = request.user
            repair.image = form_data.cleaned_data['image']
            repair.cena = form_data.cleaned_data['cena']
            repair.ime = form_data.cleaned_data['ime']


            repair.save()
            return redirect("/outofstock")



    queryset = Product.objects.filter(user=request.user,kolicina=0,kategorija__active=True).all()
    context = {"foods": queryset, "form": FoodForm}

    return render(request, "outofstock.html",context)

# Create your views here.
