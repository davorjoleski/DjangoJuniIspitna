from django.contrib import admin

from . import models
from .models import Pilot, AirCompany, Zamena, Baloon, Flights


class Zamenainline(admin.StackedInline):
    model = models.Zamena
    extra = 1


class AirplaneAdmin(admin.ModelAdmin):
    # fields = ('sifra', 'ime_poletuva', 'ime_sletuva', 'image', 'pilot', 'aviokomp')

    inlines = [Zamenainline]
    exclude = ("user",)  # avtomacki
    list_display = ["ime_komp", ]
    list_filter = ("ime_komp",)

    def has_change_permission(self, request, obj=None):
        if obj and (obj.user == request.user):
            return True
        return False

    def has_delete_permission(self, request, obj=None):

        return False

    def save_model(self, request, obj, form, change):
        if obj is not None:
            obj.user = request.user

        super().save_model(request, obj, form, change)


class PilotAdmin(admin.ModelAdmin):
    list_display = ["ime", "prezime"]
    list_filter = ("ime",)

admin.site.register(Pilot, PilotAdmin)
admin.site.register(AirCompany, AirplaneAdmin)
admin.site.register(Baloon)
admin.site.register(Flights)

# Register your models here.
