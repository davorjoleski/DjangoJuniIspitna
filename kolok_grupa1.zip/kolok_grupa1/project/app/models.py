from django.contrib.auth.models import User
from django.db import models


class Baloon(models.Model):
    tip = models.CharField(max_length=255, null=False, blank=False)
    ime_prozivod = models.CharField(max_length=255, null=False, blank=False)
    max_patnici = models.IntegerField()

    def __str__(self):
        return f"{self.tip} - {self.ime_prozivod}"


class Pilot(models.Model):
    ime = models.CharField(max_length=255, null=False, blank=False)
    prezime = models.CharField(max_length=255, null=False, blank=False)
    god = models.IntegerField()
    vk_casovi = models.IntegerField()
    cin = models.CharField(max_length=255, null=False, blank=False)

    def __str__(self):
        return f"{self.ime} - {self.prezime}"


class AirCompany(models.Model):
    ime_komp = models.CharField(max_length=255, null=False, blank=False)
    god_osnovajne = models.IntegerField()
    nadvor_od_evropa = models.BooleanField()
    # pilot = models.ForeignKey(Pilot, on_delete=models.CASCADE, null=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=False, default=1)  # Set a default value

    def __str__(self):
        return f"{self.ime_komp}"


class Flights(models.Model):
    sifra = models.CharField(max_length=255, null=False, blank=False)
    ime_poletuva = models.CharField(max_length=255, null=False, blank=False)
    ime_sletuva = models.CharField(max_length=255, null=False, blank=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=False)
    image = models.ImageField(upload_to="airplane/", null=False)
    infor = models.TextField()
    baloon = models.ForeignKey(Baloon, on_delete=models.CASCADE, null=False)
    pilot = models.ForeignKey(Pilot, on_delete=models.CASCADE, null=False)
    aviokomp = models.ForeignKey(AirCompany, on_delete=models.CASCADE, null=False)

    FRESHMAN = "FR"
    SOPHOMORE = "SO"
    JUNIOR = "JR"
    SENIOR = "SR"
    GRADUATE = "GR"

    YEAR_IN_SCHOOL_CHOICES = [
        ("FR", "Freshman"),
        ("SO", "Sophomore"),
        ("JR", "Junior"),
        ("SR", "Senior"),
        ("GR", "Graduate"),
    ]
    month = models.CharField(max_length=25,
                             choices=YEAR_IN_SCHOOL_CHOICES,
                             default="FR")

    def __str__(self):
        return f"{self.ime_poletuva} - {self.ime_sletuva} -{self.sifra}"


class Zamena(models.Model):
    aviokomp = models.ForeignKey(to=AirCompany, on_delete=models.CASCADE, null=False)
    pilot = models.ForeignKey(Pilot, on_delete=models.CASCADE, null=False)
