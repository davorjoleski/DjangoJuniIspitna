from django.shortcuts import render, redirect
from .models import *
from .form import FlightForm
from .models import Flights


def index(request):
    return render(request, "index.html")


# Create your views here.


def flights(request):
    if request.method == "POST":
        form_data = FlightForm(data=request.POST, files=request.FILES)
        if form_data.is_valid():
            book = form_data.save(commit=False)
            book.user = request.user
            book.image = form_data.cleaned_data['image']
            book.save()
            return redirect("/flights")

    query = Flights.objects.filter(user=request.user,ime_poletuva='Skopje').all()
    context = {"flights": query, "form": FlightForm}

    return render(request, 'flights.html', context=context)
